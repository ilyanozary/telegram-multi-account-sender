admins = [7459925039] # Admin UserIDs
token = "8459747449:AAEc9dLtFjSD2Ob-St_yoSvX6yvuh5HmZds" # Bot Token

host_db = 'localhost'
database = 'testbotily' # Database Name
user_db = 'bot' # Database Username
passwd_db = 'root12' # Database Password
port = 3306

python_version = "python3"